_rdp_toolkit_completion() {
    local cur words
    cur="${COMP_WORDS[COMP_CWORD]}"
    words="doctor config tunnel vm rdp session start stop status notify --help --version"
    COMPREPLY=( $(compgen -W "${words}" -- "${cur}") )
}
complete -F _rdp_toolkit_completion rdp-toolkit
